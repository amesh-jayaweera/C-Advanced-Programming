g++ -std=c++11 Main.cpp -lpthread -o main
./main